#pragma once
#include"defines.h"
#include"error.h"
#include"types.h"
#include"vector.h"
#include"list.h"
#include"deque.h"

int is_deque(void** container) {
	if (OPENCSTL_NIDX(((void**)container), -1) > INT_MAX) //���� ���� �Ǵ�
		return 1;
	return 0;
}

void cstl_push_back(void* container, ...) {
	va_list vl;
	va_start(vl, container);
	void* value = vl;
	size_t container_type;
	if (is_deque((void**)container)) {
#if defined(WIN32)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (int)OPENCSTL_NIDX(((void**)container), -1) + 1);
#elif defined(WIN64)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (_int64)OPENCSTL_NIDX(((void**)container), -1) + 1);
#endif
	}
	else {
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE);
	}
	switch (container_type) {
	case OPENCSTL_VECTOR: {
		__cstl_vector_push_back((void**)container, value);
	}break;
	case OPENCSTL_LIST: {
		//		__cstl_list_push_back_front((void**)container, value, -1, 0);
	}break;
	case OPENCSTL_DEQUE: {
		__cstl_deque_push_back((void**)container, value);
	}break;
	default:cstl_error("Invalid operator"); break;
	}
}
void cstl_push_front(void* container, ...) {
	va_list vl;
	va_start(vl, container);
	void* value = vl;
	size_t container_type;
	if (is_deque((void**)container)) {
#if defined(WIN32)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (int)OPENCSTL_NIDX(((void**)container), -1) + 1);
#elif defined(WIN64)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (_int64)OPENCSTL_NIDX(((void**)container), -1) + 1);
#endif
	}
	else {
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE);
	}
	switch (container_type) {
	case OPENCSTL_LIST: {
		//		__cstl_list_push_back_front((void**)container, value, 0, -1);
	}break;
	case OPENCSTL_DEQUE: {
		__cstl_deque_push_front((void**)container, value);
	}break;
	default:cstl_error("Invalid operator"); break;
	}
}
void cstl_pop_back(void* container) {
	size_t container_type;
	if (is_deque((void**)container)) {
#if defined(WIN32)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (int)OPENCSTL_NIDX(((void**)container), -1) + 1);
#elif defined(WIN64)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (_int64)OPENCSTL_NIDX(((void**)container), -1) + 1);
#endif
	}
	else {
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE);
	}
	switch (container_type) {
	case OPENCSTL_VECTOR: {
		__cstl_vector_pop_back((void**)container);
	}break;
	case OPENCSTL_LIST: {
		//		__cstl_list_pop_back_front((void**)container, -1, 0);
	}break;
	case OPENCSTL_DEQUE: {
		__cstl_deque_pop_back((void**)container);
	}break;
	}
}

void cstl_pop_front(void* container) {
	size_t container_type;
	if (is_deque((void**)container)) {
#if defined(WIN32)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (int)OPENCSTL_NIDX(((void**)container), -1) + 1);
#elif defined(WIN64)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (_int64)OPENCSTL_NIDX(((void**)container), -1) + 1);
#endif
	}
	else {
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE);
	}
	switch (container_type) {
	case OPENCSTL_LIST: {
		//		__cstl_list_pop_back_front((void**)container, 0, -1);
	}break;
	case OPENCSTL_DEQUE: {
		__cstl_deque_pop_front((void**)container);
	}break;
	}
}

size_t cstl_size(void* container) {
	size_t container_type;
	if (is_deque((void**)container)) {
#if defined(WIN32)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (int)OPENCSTL_NIDX(((void**)container), -1) + 1);
#elif defined(WIN64)
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE + (_int64)OPENCSTL_NIDX(((void**)container), -1) + 1);
#endif
	}
	else {
		container_type = OPENCSTL_NIDX(((void**)container), NIDX_CTYPE);
	}
	size_t sz = 0;
	switch (container_type) {
	case OPENCSTL_VECTOR: {
		sz = __cstl_vector_size((void**)container);
	}break;
	case OPENCSTL_LIST: {
		//		sz = __cstl_list_size((void**)container);
	}break;
	case OPENCSTL_DEQUE: {
		sz = __cstl_deque_size((void**)container);
	}break;
	}
	return sz;
}



void* cstl_next(void* it) {
	size_t node_type = OPENCSTL_NIDX(&it, -3);
	switch (node_type) {
	case OPENCSTL_LIST: {
		//		return __cstl_list_next_prev(it, -1);
	}break;
	}
	return NULL;
}
void *cstl_prev(void* it) {
	size_t node_type = OPENCSTL_NIDX(&it, -3);
	switch (node_type) {
	case OPENCSTL_LIST: {
		//		return __cstl_list_next_prev(it, -2);
	}break;
	}
	return NULL;
}

//#define cstl_insert(container,...)   _cstl_insert(container,ARGN(__VA_ARGS__),__VA_ARGS__)
//
//void _cstl_insert(void* container, int argc, ...) {
//	va_list vl;
//	va_start(vl, argc);
//	void* param1 = vl;
//	void* param2 = (char*)param1 + sizeof(void*);
//	void* param3 = (char*)param2 + sizeof(void*);
//	size_t container_type = OPENCSTL_NIDX((void**)container, NIDX_CTYPE);
//	switch (container_type) {
//	case OPENCSTL_VECTOR: {
//
//	}break;
//	case OPENCSTL_LIST: {
//		if (argc == 2)__cstl_list_insert((void**)container, param1, 1, param2);
//		else __cstl_list_insert((void**)container, param1, *(int*)param2, param3);
//	}break;
//	case OPENCSTL_TREE: {
//		//__ccl_tree_insert((void**)container, value);
//	}break;
//	}
//}